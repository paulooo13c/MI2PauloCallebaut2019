//https://github.com/toddmotto/public-apis link voor oef te maken
(function () {
	"use strict";

	function handleError(err) {
		console.log('Request failed', err)
	}

	function handleResponse(resp) {
		console.log('response status: ', resp.status);
		return resp.json();
	}

	function handleSuccess(data) {
		console.log('status: ', data);
		console.log('data received: ', data);
		var table = document.getElementById("songs");
		for(let i = 0; i < data.length; i++) {
			let tr = document.createElement('tr');
			tr.innerHTML = '<td>' + data[i].title + '</td>'
			+ '<td>' + data[i].type + '</td>';
			table.appendChild(tr);
		}

	}

	document.getElementById("btnSearch").addEventListener("click", function (e) {
		e.preventDefault();
		let id = document.getElementById("artist").value;
		let url = 'http://www.songsterr.com/a/ra/songs/byartists.json?artists="' + id + '"';
		fetch(url)
			.then(handleResponse)
			.then(handleSuccess)
			.catch(handleError);
	});
})();